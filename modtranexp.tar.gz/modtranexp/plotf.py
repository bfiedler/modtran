#!/usr/bin/env python
# 19 February 2025
import sys
import numpy as np
import matplotlib.pyplot as plt
from optparse import OptionParser
usage="usage: %prog expnames [options]"
parser = OptionParser(usage=usage, version="%prog 0.1")
parser.add_option("-s",  help="show plot",action="store_true", dest="s", default=False)

(opt, args) = parser.parse_args()

infn1=args[0].replace("F.csv","")
infn2=''
if len(args)>1: infn2=args[1].replace("F.csv","")
oufn=infn1+infn2

def getrad(infn):
    data=np.loadtxt(infn+"F.csv")
    wvn = data[:,0].tolist()
    irrad = 3.1415*1.e4*data[:,8]
    rad = irrad.tolist()
    totrad= 3.1415*1.e4*data[-1,-2]
    return wvn,rad,totrad
twodec = "{:.2f}"
wvn1,rad1,totrad1=getrad(infn1)
totradf1 = twodec.format(totrad1)
print(infn1,totradf1)
ttl=infn1+" "+r"$F\uparrow=$"+totradf1
if infn2:
    wvn2,rad2,totrad2=getrad(infn2)
    totradf2 = twodec.format(totrad2)
    print(infn2,totradf2)
    delta=totrad2-totrad1
    deltaf=twodec.format(delta)
    ttl+='  |  '+infn2+r" $F\uparrow=$"+totradf2+r"   |   $\Delta F\uparrow$="+deltaf

plt.figure(figsize=(20, 10))
plt.plot(wvn1,rad1,lw=2,label=infn1,color='b')
if infn2:
    plt.plot(wvn2,rad2,lw=1,label=infn2,color='r')
plt.xticks(fontsize=18)
plt.yticks(fontsize=18)
plt.xlabel("wavenumber $(\mathrm{cm}^{-1}$)",fontsize=24)
plt.ylabel("spectral irradiance $(\mathrm{W}\ \mathrm{m}^{-2}\ \mathrm{cm}$)",fontsize=24)
plt.title(ttl,fontsize=24)
plt.legend(fontsize=24)
plt.savefig(oufn+"F.svg")
plt.savefig(oufn+"F.png")
if opt.s: plt.show()

