#!/usr/bin/env python
# 19 February 2025
import sys, math
import numpy as np
import matplotlib.pyplot as plt
from optparse import OptionParser
usage="usage: %prog expnames [options]"
parser = OptionParser(usage=usage, version="%prog 0.1")
parser.add_option("-T",  help="plot T instead of RH",action="store_true", dest="T", default=False)
parser.add_option("-s",  help="show plot",action="store_true", dest="s", default=False)

(opt, args) = parser.parse_args()

infn1=args[0]
infn2=''
if len(args)>1: infn2=args[1]
oufn=infn1+infn2

def rhprof(T,h):
    rh=[]
    for i in range(len(T)):
        stvp=satvap(T[i])
        rhum = h[i]/stvp
        rh.append(rhum)
    return rh

def satvap(T): 
    return 6.11*math.exp(5422.*(1/273. - 1./T))

def getcol(infn):
    data=np.loadtxt(infn+"P.csv")
    zkm = data[:,1].tolist()
    pmb = data[:,2].tolist()
    tk = data[:,3].tolist()
    h2omb = data[:,4].tolist()
    o3mb = data[:,5].tolist()
    co2mb = data[:,6].tolist()
    ch4mb = data[:,8].tolist()
    return zkm,pmb,tk,h2omb,o3mb,co2mb,ch4mb 

zkm,pmb,tk,h2omb,o3mb,co2mb,ch4mb=getcol(infn1)
rh = rhprof(tk,h2omb) 

twodec = "{:.2f}"
#ttl=infn1+" "

plt.figure(figsize=(5, 10))
if opt.T:
    plt.plot(tk,zkm,lw=2,label=infn1,color='b',marker="o")
    ttl="Temperature"
    xx='T'
    plt.xlabel("T (K)",fontsize=24)
else:
    plt.plot(rh,zkm,lw=2,label=infn1,color='b',marker="o")
    ttl="Relative Humidity"
    xx='RH'
    plt.xlabel("RH",fontsize=24)
if infn2:
    zkm,pmb,tk,h2omb,o3mb,co2mb,ch4mb=getcol(infn2)
    rh = rhprof(tk,h2omb) 
    if opt.T:
        plt.plot(tk,zkm,lw=1,label=infn2,color='r',marker="o")
    else:
        plt.plot(rh,zkm,lw=1,label=infn2,color='r',marker="o")
plt.xticks(fontsize=18)
plt.yticks(fontsize=18)
plt.ylabel("altitude (km)",fontsize=24)
plt.title(ttl,fontsize=24)
plt.legend(fontsize=16)
plt.tight_layout()
plt.savefig(oufn+"_P"+xx+".svg")
plt.savefig(oufn+"_P"+xx+".png")
if opt.s: plt.show()

