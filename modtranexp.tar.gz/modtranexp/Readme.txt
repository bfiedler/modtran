# Reproduces the figures at https://thoughts.12characters.net/doku.php?id=modtran
# Brian Fiedler 19 February 2025
# You can make this Readme.txt executable
rm *.csv
rm *.svg
rm *.png
./extract.py *.out
./plotp.py 300ppm20km 600ppm20kmT125RH 
./plotf.py 300ppm20km 0ppm20km
./plotf.py 300ppm20km 600ppm20km 
./plotf.py 300ppm20km 300ppm20kmCH136
./plotf.py 300ppm20km 600ppm20kmT88
./plotf.py 300ppm20km 600ppm20kmT125RH
./plotf.py 300ppm20km 300ppm70km
./plotf.py 300ppm20km 600ppm70km
./plotf.py 300ppm20km 600ppm70kmT105RH


