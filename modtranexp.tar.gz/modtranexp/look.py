#!/usr/bin/env python
import sys
infn=sys.argv[1]
lines=open(infn,'r').readlines()
for line in lines:
    if len(line)>7 and line[7]==".": print(line.strip())

