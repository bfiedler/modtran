#!/usr/bin/env python
# 19 February 2025
import sys
def fluxandprofile(fileprefix):
    infn=fileprefix+".out" # from https://climatemodels.uchicago.edu/modtran/
    oufn=fileprefix+"F.csv" # for spectral irradiance
    oufn2=fileprefix+"P.csv" # for profiles

    lines=open(infn,'r').readlines()
    print(infn)

    ouf=open(oufn,'w')
    for line in lines:
        if len(line)>7 and line[7]==".": print(line.strip(),file=ouf)
    ouf.close()
    print(oufn)

    ouf2=open(oufn2,'w')
    for n in range(104,137):
        ouf2.write(lines[n])
    ouf2.close()
    print(oufn2)
    print()

for f in sys.argv[1:]:
    ff = f.replace(".out","")
    fluxandprofile(ff)


